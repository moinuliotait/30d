<?php


namespace App\Repositories\lifeStyle;


interface LifeStyleRepositoryInterface
{

}
