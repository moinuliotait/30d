<?php


namespace App\Repositories\ContentType;


interface ContentTypeRepositoryInterface
{

}
