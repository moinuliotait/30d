<?php


namespace App\Repositories\Converter;


interface ConverterRepositoryInterface
{

}
