<?php


namespace App\Repositories\ContentTypeCategory;


interface ContentTypeCategoryRepositoryInterface
{

}
