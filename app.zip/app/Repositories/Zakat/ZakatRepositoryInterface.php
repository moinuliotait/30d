<?php


namespace App\Repositories\Zakat;


interface ZakatRepositoryInterface
{

}
