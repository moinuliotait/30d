<?php


namespace App\Repositories\Zakat;


use App\Repositories\BasicRepository;
use App\Repositories\Calculation\CalculationRepositoryInterface;
use App\Repositories\MetalPrice\MetalPriceRepositoryInterface;

class ZakatRepository  implements ZakatRepositoryInterface
{




    public function neshabAmountForZakat()
    {

    }
}
