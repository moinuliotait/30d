<?php


namespace App\Repositories\Hadith;


interface HadithRepositoryInterface
{

}
