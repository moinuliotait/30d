<?php


namespace App\Repositories\NewsPortal;


interface NewsPortalRepositoryInterface
{

}
