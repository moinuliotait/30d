<?php


namespace App\Repositories\Namaz;


interface NamazRepositoryInterface
{

}
