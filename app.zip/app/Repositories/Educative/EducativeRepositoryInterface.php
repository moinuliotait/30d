<?php


namespace App\Repositories\Educative;


interface EducativeRepositoryInterface
{

}
