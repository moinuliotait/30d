<?php


namespace App\Repositories\Quran;


interface QuranRepositoryInterface
{

}
