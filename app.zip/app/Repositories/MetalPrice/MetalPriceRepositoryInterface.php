<?php


namespace App\Repositories\MetalPrice;


use Illuminate\Database\Eloquent\Model;

interface MetalPriceRepositoryInterface
{

}
