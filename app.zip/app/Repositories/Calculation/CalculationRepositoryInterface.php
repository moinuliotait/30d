<?php


namespace App\Repositories\Calculation;


interface CalculationRepositoryInterface
{
//public function __construction();
}
