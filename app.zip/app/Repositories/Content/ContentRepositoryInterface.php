<?php


namespace App\Repositories\Content;


interface ContentRepositoryInterface
{

}
